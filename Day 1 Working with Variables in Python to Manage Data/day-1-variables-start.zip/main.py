# name = input("What is your name?")
# print(name)

name = "jack"
print(name)

name = "angela"
print(name)

#print(len(input("what is your name?")))
name = input("what is your name?")
length = len(name)
print(length)